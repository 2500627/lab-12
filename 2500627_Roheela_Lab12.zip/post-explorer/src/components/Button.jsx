export default function Button({ children, onClick, style = {}, type = 'button' }) {
  const defaultStyle = {
    padding: '0.45rem 0.9rem',
    backgroundColor: '#2563eb',
    color: '#ffffff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.9rem',
    ...style,
  };

  return (
    <button type={type} onClick={onClick} style={defaultStyle}>
      {children}
    </button>
  );
}