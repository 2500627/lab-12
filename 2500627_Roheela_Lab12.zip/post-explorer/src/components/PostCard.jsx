import Card from './Card';
import Button from './Button';

export default function PostCard({ post, liked, onToggleLike, isSelected, onSelectComments }) {
  const shortBody = post.body.length > 80 ? post.body.slice(0, 80) + '...' : post.body;

  return (
    <Card>
      <h3 style={{ marginTop: 0, textTransform: 'capitalize' }}>{post.title}</h3>
      <p style={{ color: '#4b5563' }}>{shortBody}</p>

      <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem' }}>
        <Button onClick={() => onToggleLike(post.id)}>
          {liked ? 'Liked ❤️' : 'Like'}
        </Button>

        <Button
          onClick={() => onSelectComments(post.id)}
          style={{ backgroundColor: isSelected ? '#1e40af' : '#4b5563' }}
        >
          {isSelected ? 'Viewing Comments' : 'Show comments'}
        </Button>
      </div>
    </Card>
  );
}