export default function Card({ children, style = {} }) {
  const cardStyle = {
    border: '1px solid #e5e7eb',
    borderRadius: '8px',
    padding: '1.25rem',
    backgroundColor: '#ffffff',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)',
    ...style,
  };

  return <div style={cardStyle}>{children}</div>;
}