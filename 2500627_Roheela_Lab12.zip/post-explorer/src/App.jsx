import { useState, useEffect, useMemo, useRef } from 'react';
import { fetchPosts } from './api/posts';
import PostCard from './components/PostCard';
import Button from './components/Button';
import Card from './components/Card';

export default function App() {
  const [posts, setPosts] = useState([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [errorPosts, setErrorPosts] = useState(null);
  const [likedIds, setLikedIds] = useState([]);
  const [search, setSearch] = useState('');
  const searchInputRef = useRef(null);
  const [selectedId, setSelectedId] = useState(null);
  const [comments, setComments] = useState([]);
  const [loadingC, setLoadingC] = useState(false);
  const [errorC, setErrorC] = useState(null);

  useEffect(() => {
    fetchPosts()
      .then(data => {
        setPosts(data);
        setLoadingPosts(false);
      })
      .catch(err => {
        setErrorPosts(err.message);
        setLoadingPosts(false);
      });
  }, []);

  useEffect(() => {
    if (selectedId === null) return;
    setLoadingC(true);
    setErrorC(null);

    fetch(`https://jsonplaceholder.typicode.com/posts/${selectedId}/comments`)
      .then(r => {
        if (!r.ok) throw new Error('Failed to fetch comments');
        return r.json();
      })
      .then(data => {
        setComments(data);
        setLoadingC(false);
      })
      .catch(e => {
        setErrorC(e.message);
        setLoadingC(false);
      });
  }, [selectedId]);

  const handleToggleLike = (id) => {
    setLikedIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const filteredPosts = useMemo(() => {
    return posts.filter(post =>
      post.title.toLowerCase().includes(search.toLowerCase())
    );
  }, [posts, search]);

  const handleFocusSearch = () => {
    searchInputRef.current?.focus();
  };

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '1.5rem', fontFamily: 'sans-serif' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h1 style={{ margin: 0 }}>Post Explorer</h1>
        <span style={{ fontSize: '1.1rem', fontWeight: 'bold' }}>
          Liked: {likedIds.length}
        </span>
      </header>

      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' }}>
        <input
          ref={searchInputRef}
          type="text"
          placeholder="Search posts by title..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ flex: 1, padding: '0.5rem', borderRadius: '6px', border: '1px solid #ccc' }}
        />
        <Button onClick={handleFocusSearch}>Focus search</Button>
      </div>

      {loadingPosts && <p>Loading posts...</p>}
      {errorPosts && <p style={{ color: 'red' }}>Error: {errorPosts}</p>}

      {!loadingPosts && !errorPosts && (
        <div style={{ display: 'grid', gap: '1rem' }}>
          {filteredPosts.map(post => (
            <div key={post.id}>
              <PostCard
                post={post}
                liked={likedIds.includes(post.id)}
                onToggleLike={handleToggleLike}
                isSelected={selectedId === post.id}
                onSelectComments={(id) => setSelectedId(prev => (prev === id ? null : id))}
              />

              {selectedId === post.id && (
                <Card style={{ marginTop: '0.5rem', backgroundColor: '#f9fafb' }}>
                  <h4 style={{ marginTop: 0 }}>Top Comments</h4>
                  {loadingC && <p>Loading comments...</p>}
                  {errorC && <p style={{ color: 'red' }}>Error: {errorC}</p>}

                  {!loadingC && !errorC && (
                    <ul style={{ paddingLeft: '1.2rem', margin: 0 }}>
                      {comments.slice(0, 3).map(comment => (
                        <li key={comment.id} style={{ marginBottom: '0.5rem' }}>
                          <strong>{comment.name}</strong> ({comment.email})
                        </li>
                      ))}
                    </ul>
                  )}
                </Card>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}