export async function fetchPosts() {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return await response.json();
  } catch (err) {
    const fallbackResponse = await fetch('/posts.json');
    if (!fallbackResponse.ok) {
      throw new Error('Failed to load posts from both API and local fallback.');
    }
    return await fallbackResponse.json();
  }
}