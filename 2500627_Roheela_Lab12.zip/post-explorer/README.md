# Post Explorer (Lab 12 Assignment)

A React + Vite application that fetches posts from JSONPlaceholder, supports immutable liking, filters posts by title with `useMemo`, focuses search via `useRef`, and loads comments on demand with `useEffect`.

## How to Run
1. `npm install`
2. `npm run dev`